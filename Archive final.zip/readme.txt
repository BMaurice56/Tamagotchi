Nom de l'équipe : Groupe 1
Benoît Maurice
Arthur Gros
Donovan Casagrande
Benjamin Haurogne

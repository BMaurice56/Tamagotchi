package com.mygdx.game.Personnage;

public class Oil extends Food {
    public static final int point = 250;

    public static final int price = 20;

    public Oil() {
        super("Oil", point);
    }
}

package com.mygdx.game.Personnage;

public class GoldenApple extends Food {

    public static final int point = 400;

    public static final int price = 60;

    public GoldenApple() {
        super("GoldenApple", point);
    }
}

package com.mygdx.game.Personnage;

public class SuperOil extends Food {

    public static final int point = 400;

    public static final int price = 60;

    public SuperOil() {
        super("SuperOil", point);
    }
}

package com.mygdx.game.Personnage;

public class Apple extends Food {

    public static final int point = 250;

    public static final int price = 20;


    public Apple() {
        super("Apple", point);
    }


}
